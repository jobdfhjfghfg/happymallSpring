package happyMall.happyMall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HappyMallApplicationTests {

	@Test
	void contextLoads() {
	}

}
