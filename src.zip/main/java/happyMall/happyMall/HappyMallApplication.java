package happyMall.happyMall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HappyMallApplication {

	public static void main(String[] args) {
		SpringApplication.run(HappyMallApplication.class, args);
	}

}
