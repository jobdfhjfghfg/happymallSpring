package happyMall.happyMall.controller;

public class SessionConst {

    public static final String LOGIN_MEMBER = "LoginMember";
}
