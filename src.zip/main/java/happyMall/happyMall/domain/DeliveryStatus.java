package happyMall.happyMall.domain;

public enum DeliveryStatus {
    READY, COMP
}
