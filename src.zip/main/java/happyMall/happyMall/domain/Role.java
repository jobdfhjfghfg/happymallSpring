package happyMall.happyMall.domain;

public enum Role {
    ADMIN, USER
}
