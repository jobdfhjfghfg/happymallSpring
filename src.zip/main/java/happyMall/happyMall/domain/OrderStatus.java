package happyMall.happyMall.domain;

public enum OrderStatus {
    ORDER, CANCEL;
}
